import java.util.List;
import java.util.ArrayList;


/**
 * A container that can be manipulated and drawn on a canvas.
 * 
 * @author Kevin Segura - Juan Cruz 
 * @version 1.0
 */
public class MaxwellContainer
{
    private int h;
    private int w;
    private List<Triangle>demons;
    private List<Circle>particles;
    private List<Circle>blackHoles;

    /**
     * Constructor for objects of class MaxwellContainer
     */
    public MaxwellContainer(int width, int height){
        this.w = width;
        this.h = height;
        this.demons = new ArrayList<>();
        this.particles = new ArrayList<>();
        this.blackHoles = new ArrayList<>();
    }
    
    
}